<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(['prefix' => 'product'], function(){
    Route::get('list', [App\Http\Controllers\ProductController::class, 'list'])->name('product.list');
    Route::get('create', [App\Http\Controllers\ProductController::class, 'create'])->name('product.create');
    Route::post('save', [App\Http\Controllers\ProductController::class, 'save'])->name('product.save');
    Route::get('edit/{id}', [App\Http\Controllers\ProductController::class, 'edit'])->name('product.edit');
    Route::post('update', [App\Http\Controllers\ProductController::class, 'update'])->name('product.update');
    Route::get('delete/{id}', [App\Http\Controllers\ProductController::class, 'delete'])->name('product.delete');
});

Route::group(['prefix' => 'data-user'], function(){
    Route::get('list', [App\Http\Controllers\DataUserController::class, 'list'])->name('data_user.list');
    Route::get('create', [App\Http\Controllers\DataUserController::class, 'create'])->name('data_user.create');
    Route::post('save', [App\Http\Controllers\DataUserController::class, 'save'])->name('data_user.save');
    Route::get('edit/{id}', [App\Http\Controllers\DataUserController::class, 'edit'])->name('data_user.edit');
    Route::post('update', [App\Http\Controllers\DataUserController::class, 'update'])->name('data_user.update');
    Route::get('delete/{id}', [App\Http\Controllers\DataUserController::class, 'delete'])->name('data_user.delete');
});

Route::group(['prefix' => 'transaction'], function(){
    Route::get('list', [App\Http\Controllers\TransactionController::class, 'list'])->name('transaction.list');
    Route::get('create', [App\Http\Controllers\TransactionController::class, 'create'])->name('transaction.create');
    Route::post('save', [App\Http\Controllers\TransactionController::class, 'save'])->name('transaction.save');
    Route::get('edit/{id}', [App\Http\Controllers\TransactionController::class, 'edit'])->name('transaction.edit');
    Route::post('update', [App\Http\Controllers\TransactionController::class, 'update'])->name('transaction.update');
    Route::get('delete/{id}', [App\Http\Controllers\TransactionController::class, 'delete'])->name('transaction.delete');
});
