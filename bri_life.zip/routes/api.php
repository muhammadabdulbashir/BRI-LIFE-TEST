<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'product'], function(){
    Route::get('list', [App\Http\Controllers\ProductController::class, 'api_list']);
    Route::post('save', [App\Http\Controllers\ProductController::class, 'api_save']);
    Route::get('detail/{id}', [App\Http\Controllers\ProductController::class, 'api_detail']);
    Route::post('update', [App\Http\Controllers\ProductController::class, 'api_update']);
    Route::get('delete/{id}', [App\Http\Controllers\ProductController::class, 'api_delete']);
});

Route::group(['prefix' => 'data-user'], function(){
    Route::get('list', [App\Http\Controllers\DataUserController::class, 'api_list']);
    Route::post('save', [App\Http\Controllers\DataUserController::class, 'api_save']);
    Route::get('detail/{id}', [App\Http\Controllers\DataUserController::class, 'api_detail']);
    Route::post('update', [App\Http\Controllers\DataUserController::class, 'api_update']);
    Route::get('delete/{id}', [App\Http\Controllers\DataUserController::class, 'api_delete']);
});

Route::group(['prefix' => 'transaction'], function(){
    Route::get('list', [App\Http\Controllers\TransactionController::class, 'api_list']);
    Route::post('save', [App\Http\Controllers\TransactionController::class, 'api_save']);
    Route::get('detail/{id}', [App\Http\Controllers\TransactionController::class, 'api_detail']);
    Route::post('update', [App\Http\Controllers\TransactionController::class, 'api_update']);
    Route::get('delete/{id}', [App\Http\Controllers\TransactionController::class, 'api_delete']);
});
