@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Transaction</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="{{route('transaction.update')}}" method="POST">
                                <input type="hidden" name="trans_id" value="{{$data->trans_id}}">
                                @csrf
                                <div class="form-group">
                                    <label>User</label>
                                    <select name="user_id" class="form-control" required>
                                        @foreach($user as $u)
                                        <option value="{{$u->user_id}}" {{$u->user_id == $data->user_id ? 'selected' : ''}}>{{$u->user_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Product</label>
                                    <select name="product_id" class="form-control" required>
                                        @foreach($product as $p)
                                        <option value="{{$p->product_id}}" {{$p->product_id == $data->product_id ? 'selected' : ''}}>{{$p->product_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Qty Order</label>
                                    <input type="text" name="qty_order" class="form-control" required value="{{$data->qty_order}}">
                                </div>
                                
                                <button type="submit" class="btn btn-success">
                                    Save
                                </button>
                                <a href="{{route('transaction.list')}}" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
