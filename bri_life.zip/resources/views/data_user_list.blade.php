@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Data User</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div class="row">
                        <div class="col-sm-6">
                            <a href="{{route('data_user.create')}}" class="btn btn-secondary">
                                Add Data
                            </a>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>User ID</th>
                                        <th>User Name</th>
                                        <th>Active</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($sql as $data)
                                    <tr>
                                        <td>{{$loop->iteration}}</td>
                                        <td>{{$data->user_id}}</td>
                                        <td>{{$data->user_name}}</td>
                                        <td>
                                            @if($data->active == '1')
                                            Active
                                            @else
                                            Deactive
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{route('data_user.edit', $data->user_id)}}" class="btn btn-info">Edit</a>
                                            <a href="{{route('data_user.delete', $data->user_id)}}" onclick="return confirm('Delete data ?')" class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="5" style="text-align: center;">
                                            nothing here
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
