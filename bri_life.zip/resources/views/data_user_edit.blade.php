@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit User</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="{{route('data_user.update')}}" method="POST">
                                <input type="hidden" name="user_id" value="{{$data->user_id}}">
                                @csrf
                                <div class="form-group">
                                    <label>User Name</label>
                                    <input type="text" name="user_name" class="form-control" required value="{{$data->user_name}}">
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="active" class="form-control" required>
                                        <option value="1" {{$data->status == '1' ? 'selected' : ''}}>Active</option>
                                        <option value="0" {{$data->status == '0' ? 'selected' : ''}}>Deactive</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-success">
                                    Update
                                </button>
                                <a href="{{route('data_user.list')}}" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
