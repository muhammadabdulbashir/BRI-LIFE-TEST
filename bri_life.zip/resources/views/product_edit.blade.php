@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Product</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="{{route('product.update')}}" method="POST">
                                <input type="hidden" name="product_id" value="{{$data->product_id}}">
                                @csrf
                                <div class="form-group">
                                    <label>Product Name</label>
                                    <input type="text" name="product_name" class="form-control" required value="{{$data->product_name}}">
                                </div>
                                <div class="form-group">
                                    <label>Premium</label>
                                    <input type="text" name="premium" class="form-control" required value="{{$data->premium}}">
                                </div>
                                <button type="submit" class="btn btn-success">
                                    Update
                                </button>
                                <a href="{{route('product.list')}}" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
