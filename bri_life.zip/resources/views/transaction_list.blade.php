@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Data Transaction</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div class="row">
                        <div class="col-sm-6">
                            <a href="{{route('transaction.create')}}" class="btn btn-secondary">
                                Add Data
                            </a>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Trans. Date</th>
                                        <th>User</th>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($sql as $data)
                                    <tr>
                                        <td>{{$loop->iteration}}</td>
                                        <td>{{$data->trans_date}}</td>
                                        <td>{{$data->user_name}}</td>
                                        <td>{{$data->product_name}}</td>
                                        <td>{{number_format($data->qty_order, 0, '', '')}}</td>
                                        <td>{{number_format($data->total_order, 0, '', '')}}</td>
                                        <td>
                                            <a href="{{route('transaction.edit', $data->trans_id)}}" class="btn btn-info">Edit</a>
                                            <a href="{{route('transaction.delete', $data->trans_id)}}" onclick="return confirm('Delete data ?')" class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="7" style="text-align: center;">
                                            nothing here
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
