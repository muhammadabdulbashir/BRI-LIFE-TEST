

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Transaction</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="<?php echo e(route('transaction.update')); ?>" method="POST">
                                <input type="hidden" name="trans_id" value="<?php echo e($data->trans_id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>User</label>
                                    <select name="user_id" class="form-control" required>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($u->user_id); ?>" <?php echo e($u->user_id == $data->user_id ? 'selected' : ''); ?>><?php echo e($u->user_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Product</label>
                                    <select name="product_id" class="form-control" required>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->product_id); ?>" <?php echo e($p->product_id == $data->product_id ? 'selected' : ''); ?>><?php echo e($p->product_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Qty Order</label>
                                    <input type="text" name="qty_order" class="form-control" required value="<?php echo e($data->qty_order); ?>">
                                </div>
                                
                                <button type="submit" class="btn btn-success">
                                    Save
                                </button>
                                <a href="<?php echo e(route('transaction.list')); ?>" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA\BRI_LIFE\bri_life\resources\views/transaction_edit.blade.php ENDPATH**/ ?>