

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Data User</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('data_user.create')); ?>" class="btn btn-secondary">
                                Add Data
                            </a>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>User ID</th>
                                        <th>User Name</th>
                                        <th>Active</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->user_id); ?></td>
                                        <td><?php echo e($data->user_name); ?></td>
                                        <td>
                                            <?php if($data->active == '1'): ?>
                                            Active
                                            <?php else: ?>
                                            Deactive
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('data_user.edit', $data->user_id)); ?>" class="btn btn-info">Edit</a>
                                            <a href="<?php echo e(route('data_user.delete', $data->user_id)); ?>" onclick="return confirm('Delete data ?')" class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" style="text-align: center;">
                                            nothing here
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA\BRI_LIFE\bri_life\resources\views/data_user_list.blade.php ENDPATH**/ ?>