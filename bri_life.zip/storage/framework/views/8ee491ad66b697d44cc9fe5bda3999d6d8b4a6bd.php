

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Product</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="<?php echo e(route('product.update')); ?>" method="POST">
                                <input type="hidden" name="product_id" value="<?php echo e($data->product_id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Product Name</label>
                                    <input type="text" name="product_name" class="form-control" required value="<?php echo e($data->product_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Premium</label>
                                    <input type="text" name="premium" class="form-control" required value="<?php echo e($data->premium); ?>">
                                </div>
                                <button type="submit" class="btn btn-success">
                                    Update
                                </button>
                                <a href="<?php echo e(route('product.list')); ?>" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA\BRI_LIFE\bri_life\resources\views/product_edit.blade.php ENDPATH**/ ?>