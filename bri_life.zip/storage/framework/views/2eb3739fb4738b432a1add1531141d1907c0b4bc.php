

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit User</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-sm-12 table-responsive">
                            <form action="<?php echo e(route('data_user.update')); ?>" method="POST">
                                <input type="hidden" name="user_id" value="<?php echo e($data->user_id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>User Name</label>
                                    <input type="text" name="user_name" class="form-control" required value="<?php echo e($data->user_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="active" class="form-control" required>
                                        <option value="1" <?php echo e($data->status == '1' ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e($data->status == '0' ? 'selected' : ''); ?>>Deactive</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-success">
                                    Update
                                </button>
                                <a href="<?php echo e(route('data_user.list')); ?>" class="btn btn-danger">
                                    Back
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA\BRI_LIFE\bri_life\resources\views/data_user_edit.blade.php ENDPATH**/ ?>