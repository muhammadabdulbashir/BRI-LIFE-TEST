<?php

namespace App\Http\Controllers;

use App\Models\DataUser;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class DataUserController extends Controller
{
    public function list()
    {
        $data['sql'] = DataUser::all();

        return view('data_user_list', $data);
    }

    public function create()
    {
        return view('data_user_add');
    }

    public function save(Request $request)
    {
        $inputData = [
            "user_id" => $request->user_id,
            "user_name" => $request->user_name,
            "active" => $request->active,
        ];

        // dd($inputData);

        $save = DataUser::create($inputData);

        return redirect()->route('data_user.list');
    }

    public function edit($id)
    {
        $data['data'] = DataUser::where('user_id', $id)->first();

        return view('data_user_edit', $data);
    }

    public function update(Request $request)
    {
        $inputData = [
            "user_name" => $request->user_name,
            "active" => $request->active,
        ];

        $save = DataUser::where('user_id', $request->user_id)->update($inputData);

        return redirect()->route('data_user.list');
    }

    public function delete($id)
    {
        $d = DataUser::where('user_id', $id)->delete();

        return redirect()->route('data_user.list');
    }

    //////////////////////////// API /////////////////////////////////////
    public function api_list()
    {
        $data = DataUser::all();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_save(Request $request)
    {
        $inputData = [
            "user_id" => $request->user_id,
            "user_name" => $request->user_name,
            "active" => $request->active,
        ];

        $save = DataUser::create($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_update(Request $request)
    {
        $inputData = [
            "user_name" => $request->user_name,
            "active" => $request->active,
        ];

        $save = DataUser::where('user_id', $request->user_id)->update($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_detail($id)
    {
        $data = DataUser::where('user_id', $id)->first();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_delete($id)
    {
        $d = DataUser::where('user_id', $id)->delete();

        if($d)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }

        return json_encode($respon);
    }
}
