<?php

namespace App\Http\Controllers;

use App\Models\Product;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{
    public function list()
    {
        $data['sql'] = Product::all();

        return view('product_list', $data);
    }

    public function create()
    {
        return view('product_add');
    }

    public function save(Request $request)
    {
        $inputData = [
            "product_name" => $request->product_name,
            "premium" => $request->premium,
        ];

        $save = Product::create($inputData);

        return redirect()->route('product.list');
    }

    public function edit($id)
    {
        $data['data'] = Product::where('product_id', $id)->first();

        return view('product_edit', $data);
    }

    public function update(Request $request)
    {
        $inputData = [
            "product_name" => $request->product_name,
            "premium" => $request->premium,
        ];

        $save = Product::where('product_id', $request->product_id)->update($inputData);

        return redirect()->route('product.list');
    }

    public function delete($id)
    {
        $d = Product::where('product_id', $id)->delete();

        return redirect()->route('product.list');
    }


    //////////////////////////// API /////////////////////////////////////
    public function api_list()
    {
        $data = Product::all();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_save(Request $request)
    {
        $inputData = [
            "product_name" => $request->product_name,
            "premium" => $request->premium,
        ];

        $save = Product::create($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_update(Request $request)
    {
        $inputData = [
            "product_name" => $request->product_name,
            "premium" => $request->premium,
        ];

        $save = Product::where('product_id', $request->product_id)->update($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_detail($id)
    {
        $data = Product::where('product_id', $id)->first();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_delete($id)
    {
        $d = Product::where('product_id', $id)->delete();

        if($d)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }

        return json_encode($respon);
    }
}
