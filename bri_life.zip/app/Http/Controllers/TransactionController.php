<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\DataUser;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class TransactionController extends Controller
{
    public function list()
    {
        $data['sql'] = Transaction::leftJoin('products', 'transactions.product_id', '=', 'products.product_id')
        ->leftJoin('data_user', 'transactions.user_id', '=', 'data_user.user_id')
        ->select('transactions.*', 'products.product_name', 'data_user.user_name')
        ->get();

        return view('transaction_list', $data);
    }

    public function create()
    {
        $data['product'] = Product::all();
        $data['user'] = DataUser::where('active', '1')->get();

        return view('transaction_add', $data);
    }

    public function save(Request $request)
    {
        date_default_timezone_set('Asia/Jakarta');

        $produk = Product::where('product_id', $request->product_id)->first();
        $total = $produk->premium * $request->qty_order;

        $inputData = [
            "trans_date" => date('Y-m-d H:i:s'),
            "user_id" => $request->user_id,
            "product_id" => $request->product_id,
            "qty_order" => $request->qty_order,
            "total_order" => $total,
        ];

        $save = Transaction::create($inputData);

        return redirect()->route('transaction.list');
    }

    public function edit($id)
    {
        $data['data'] = Transaction::where('trans_id', $id)->first();
        $data['product'] = Product::all();
        $data['user'] = DataUser::where('active', '1')->get();

        return view('transaction_edit', $data);
    }

    public function update(Request $request)
    {
        date_default_timezone_set('Asia/Jakarta');
        $produk = Product::where('product_id', $request->product_id)->first();
        $total = $produk->premium * $request->qty_order;

        $inputData = [
            "trans_date" => date('Y-m-d H:i:s'),
            "user_id" => $request->user_id,
            "product_id" => $request->product_id,
            "qty_order" => $request->qty_order,
            "total_order" => $total,
        ];

        $save = Transaction::where('trans_id', $request->trans_id)->update($inputData);

        return redirect()->route('transaction.list');
    }

    public function delete($id)
    {
        $d = Transaction::where('trans_id', $id)->delete();

        return redirect()->route('transaction.list');
    }

    //////////////////////////// API /////////////////////////////////////
    public function api_list()
    {
        $data = Transaction::all();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_save(Request $request)
    {
        date_default_timezone_set('Asia/Jakarta');

        $produk = Product::where('product_id', $request->product_id)->first();
        $total = $produk->premium * $request->qty_order;

        $inputData = [
            "trans_date" => date('Y-m-d H:i:s'),
            "user_id" => $request->user_id,
            "product_id" => $request->product_id,
            "qty_order" => $request->qty_order,
            "total_order" => $total,
        ];

        $save = Transaction::create($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_update(Request $request)
    {
        date_default_timezone_set('Asia/Jakarta');
        $produk = Product::where('product_id', $request->product_id)->first();
        $total = $produk->premium * $request->qty_order;

        $inputData = [
            "trans_date" => date('Y-m-d H:i:s'),
            "user_id" => $request->user_id,
            "product_id" => $request->product_id,
            "qty_order" => $request->qty_order,
            "total_order" => $total,
        ];

        $save = Transaction::where('trans_id', $request->trans_id)->update($inputData);

        if($save)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01",
            ];
        }

        return json_encode($respon);
    }

    public function api_detail($id)
    {
        $data = Transaction::where('trans_id', $id)->first();

        if($data->count() == 0)
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "00",
                "ResponseDesc" => $data
            ];
        }

        return json_encode($respon);
    }

    public function api_delete($id)
    {
        $d = Transaction::where('trans_id', $id)->delete();

        if($d)
        {
            $respon = [
                "ResponseCode" => "00"
            ];
        }
        else
        {
            $respon = [
                "ResponseCode" => "01"
            ];
        }

        return json_encode($respon);
    }
}
